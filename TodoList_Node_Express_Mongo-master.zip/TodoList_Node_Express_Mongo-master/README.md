# TodoList_Node_Express_Mongo
A TodoList using Node Express and Mongo in which u can add and delete items
